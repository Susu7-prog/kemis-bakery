import type { MetadataRoute } from "next";
import { siteConfig } from "@/lib/config/site";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/", disallow: ["/login", "/account", "/checkout"] },
    sitemap: `${siteConfig.url}/sitemap.xml`,
  };
}
